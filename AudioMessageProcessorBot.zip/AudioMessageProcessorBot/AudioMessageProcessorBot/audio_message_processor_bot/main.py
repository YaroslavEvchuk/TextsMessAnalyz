from aiogram import F
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message, ContentType, File, Message, FSInputFile
import whisper
import pickle
import pandas as pd
from wordcloud import WordCloud
import sqlite3


# Переменные необходимые для работы бота
BOT_TOKEN = "6973253048:AAHy5HmA_JpIbYtWGbaFgzeXaqe_vD5aAR8"  # заменить на свой токен
BOT = Bot(token=BOT_TOKEN)
DISPATCHER = Dispatcher()

# Модели машинного обучения для векторизации предложения, а также анализа настроения текста
vectorizer = pickle.load(open("vectorizer.pickle", "rb"))
model_predictor = pickle.load(open("log_reg.pickle", "rb"))

# Соединение с базой данных
con = sqlite3.connect("TelegramMessages.db")
cursor = con.cursor()


async def process_start_command(message: Message):
    await message.answer(
        "Добро пожаловать! Данный бот может расшифровать ваши текста, а также оценить их настроение. Приятного пользования!"
    )


async def help(message: Message):
    await message.answer(
        """ /requests  - команда, которая возвращает все запросы пользователя в виде csv файла.\n/wordcloud - команда, которая возвращает облако слов на основании запросов пользователя.\n/help - команда, которая возвращает описание всех остальных команд.\n\nОтветом на голосовое сообщение является облако слов, сформированное на основании данного сообщения. А также, оценка настроения данного сообщения и его расшифровка.\n\nПри вводе обычного текста будет выведена оценка настроения данного текста."""
    )  # Функция, которая возвращает все возможные варианты взаимодействия с ботом.


@DISPATCHER.message(F.voice)
async def voice_message_handler(message: Message):
    voice = await BOT.get_file(message.voice.file_id)  # обрабатываем гс
    voice_path = voice.file_path  # получение ссылки на гс от телеги
    await BOT.download_file(
        voice_path, f"files/voices/{voice.file_id}.mp3"
    )  # сохраняем гс на пк
    model = whisper.load_model(
        "base"
    )  # модель для расшифровки гс, base можно поменять на medium, если достаточно оперативки
    result = model.transcribe(
        f"files/voices/{voice.file_id}.mp3", language="ru"
    )  # процесс расшифровки, можно поменять language на en или любой др.
    text = result["text"]
    print(text, type(text))
    series = pd.Series(
        data={1: text}, index=[1]
    )  # обрабатываем текст из гс для классификации настроения
    print(series.head())
    transformed_message = vectorizer.transform(
        series
    )  # обрабатываем текст из гс для классификации настроения
    # asdasd asd gsdf gsdg jdfgjh
    # asd gsdf
    # 0     1    1    0     0
    # [0.123123 0.87]
    print(transformed_message.shape)
    print(model_predictor.predict_proba(transformed_message))
    WordCloud().generate_from_text(text).to_file(
        f"files/images/{voice.file_id}.png"
    )  # генерация облака слов
    ans = (
        "Негативный текст."
        if model_predictor.predict(transformed_message)[0] == 0
        else "Позитивный текст"
    )  # классификация настроения сообщения

    ans += f' "{text.strip()}"'  # добавляем к результату само расшифрованное сообщение
    print(message.from_user.id)
    cursor.execute(
        "INSERT INTO messages(user_id, message) VALUES (?, ?)",
        (message.from_user.id, text),
    )  # заносим результат в базу данных
    con.commit()
    await message.reply_photo(
        FSInputFile(path=f"files/images/{voice.file_id}.png"),
        caption=ans,
    )  # ответ бота


async def send_user_request(message: Message):
    messages_df = pd.read_sql_query(
        f"SELECT * from messages WHERE user_id={message.from_user.id}", con
    )  # Читаем данные из базы данных
    messages_df.to_csv(
        f"files/csv/{message.message_id}.csv", index=False
    )  # Сохраняем их в формате csv в папку file/csv
    await message.answer_document(
        FSInputFile(path=f"files/csv/{message.message_id}.csv"),
        caption=f"Файл для пользователя {message.from_user.full_name}",
    )  # Бот отправляет пользователю файл и сообщение


async def wordcloud_by_user_handler(message: Message):
    messages_df = pd.read_sql_query(
        f"SELECT * from messages WHERE user_id={message.from_user.id}", con
    )  # Читаем данные из базы данных
    WordCloud().generate(" ".join(messages_df["message"])).to_file(
        f"files/images/{message.message_id}.png"
    )  # Генерируем и сохраняем облако слов в files/images
    await message.answer_photo(
        FSInputFile(path=f"files/images/{message.message_id}.png"),
        caption=f"Облако слов для пользователя {message.from_user.full_name}.",
    )  # Отрпавляем облако слов и подпись к нему в качестве ответа пользователю


# Регистрация команд взаимодействия с ботом
DISPATCHER.message.register(process_start_command, Command(commands=["start"]))
DISPATCHER.message.register(wordcloud_by_user_handler, Command(commands=["wordcloud"]))
DISPATCHER.message.register(send_user_request, Command(commands=["requests"]))
DISPATCHER.message.register(help, Command(commands=["help"]))


@DISPATCHER.message(F.text)
async def text_message_handler(message: Message):
    model = whisper.load_model(
        "base"
    )  # модель для расшифровки гс, base можно поменять на medium, если достаточно оперативки
    text = message.text
    print(text, type(text))
    series = pd.Series(
        data={1: text}, index=[1]
    )  # обрабатываем текст из гс для классификации настроения
    print(series.head())
    transformed_message = vectorizer.transform(
        series
    )  # обрабатываем текст из гс для классификации настроения
    # asdasd asd gsdf gsdg jdfgjh
    # asd gsdf
    # 0     1    1    0     0
    # [0.123123 0.87]
    print(transformed_message.shape)
    print(model_predictor.predict_proba(transformed_message))
    WordCloud().generate_from_text(text).to_file(
        f"files/images/{message.message_id}.png"
    )  # генерация облака слов
    ans = (
        "Негативный текст."
        if model_predictor.predict(transformed_message)[0] == 0
        else "Позитивный текст"
    )  # классификация настроения сообщения

    ans += f' "{text.strip()}"'  # добавляем к результату само расшифрованное сообщение
    print(message.from_user.id)
    cursor.execute(
        "INSERT INTO messages(user_id, message) VALUES (?, ?)",
        (message.from_user.id, text),
    )  # заносим результат в базу данных
    con.commit()
    await message.reply_photo(
        FSInputFile(path=f"files/images/{message.message_id}.png"),
        caption=ans,
    )  # ответ бота


def main():
    DISPATCHER.run_polling(BOT)  # Запуск бота


if __name__ == "__main__":
    main()
